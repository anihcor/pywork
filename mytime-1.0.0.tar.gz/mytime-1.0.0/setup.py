from distutils.core import setup
setup(
        name = 'mytime',
        version = '1.0.0',
        py_modules = ['mytime'],
        author = 'wha',
        author_email = 'hansonwey@163.com',
        #url = 'http://www.headfirstlabs.com',
        description = 'A simple way to get time',
    )
'''
在命令行cmd（或linux shell，这里以windows cmd为例）中
执行：python setup.py sdist
注意执行目录为前面新建的文件夹下。
将发布安装到Python本地库中使用
执行：python setup.py install
'''
